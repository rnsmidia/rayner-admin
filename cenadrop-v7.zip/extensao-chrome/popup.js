// popup.js — CenaDrop Flow v7.0

const API_URL = 'https://darkflow-server.vercel.app/api/verify';

// ════════════════════════════════════════════════════════════════════════════
// DEVICE FINGERPRINT
// ════════════════════════════════════════════════════════════════════════════
async function getDeviceId() {
  const stored = await chrome.storage.local.get(['cd_device_id']);
  if (stored.cd_device_id) return stored.cd_device_id;
  const raw = navigator.userAgent + navigator.language + screen.width + screen.height + Date.now() + Math.random();
  const buf  = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
  const id   = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('').substring(0, 32);
  await chrome.storage.local.set({ cd_device_id: id });
  return id;
}

// ════════════════════════════════════════════════════════════════════════════
// LICENSE
// ════════════════════════════════════════════════════════════════════════════
async function checkLicense() {
  const stored = await chrome.storage.local.get(['cd_license_key', 'cd_license_valid']);
  if (!stored.cd_license_key) { showLicenseScreen(); return; }
  try {
    const deviceId = await getDeviceId();
    const r = await fetch(API_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ key: stored.cd_license_key, deviceId }) });
    const data = await r.json();
    if (data.valid) { await chrome.storage.local.set({ cd_license_valid: true }); showApp(); }
    else { await chrome.storage.local.remove(['cd_license_valid','cd_last_check']); showLicenseScreen(data.error || 'Licença inválida.'); }
  } catch(e) {
    if (stored.cd_license_valid) showApp();
    else showLicenseScreen('Sem conexão. Verifique sua internet.');
  }
}

function showLicenseScreen(errMsg = '') {
  document.getElementById('licenseScreen').style.display = 'flex';
  document.getElementById('mainScreen').style.display    = 'none';
  if (errMsg) document.getElementById('licError').textContent = '⚠️ ' + errMsg;
}

async function activateLicense() {
  const key   = document.getElementById('licKey').value.trim().toUpperCase();
  const errEl = document.getElementById('licError');
  const btn   = document.getElementById('licBtn');
  errEl.textContent = '';
  if (key.length < 8) { errEl.textContent = 'Digite uma chave válida.'; return; }
  btn.disabled = true; btn.textContent = 'Verificando...';
  try {
    const deviceId = await getDeviceId();
    const r = await fetch(API_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ key, deviceId }) });
    const data = await r.json();
    if (data.valid) {
      await chrome.storage.local.set({ cd_license_key: key, cd_license_valid: true, cd_last_check: Date.now() });
      showApp();
    } else {
      errEl.textContent = '❌ ' + (data.error || 'Chave inválida');
      btn.disabled = false; btn.textContent = 'Ativar Licença';
    }
  } catch(e) {
    errEl.textContent = '❌ Erro de conexão.';
    btn.disabled = false; btn.textContent = 'Ativar Licença';
  }
}

function formatKey(input) { input.value = input.value.toUpperCase().replace(/[^A-Z0-9-]/g, ''); }

function showApp() {
  document.getElementById('licenseScreen').style.display = 'none';
  document.getElementById('mainScreen').style.display    = 'block';
  _init();
}

async function logout() {
  await chrome.storage.local.remove(['cd_license_key','cd_license_valid','cd_last_check']);
  document.getElementById('licenseScreen').style.display = 'flex';
  document.getElementById('mainScreen').style.display    = 'none';
  document.getElementById('licKey').value = '';
  document.getElementById('licError').textContent = '';
  document.getElementById('licBtn').disabled = false;
  document.getElementById('licBtn').textContent = 'Ativar Licença';
}

// ════════════════════════════════════════════════════════════════════════════
// RESET DEVICE
// ════════════════════════════════════════════════════════════════════════════
async function resetDevice(key) {
  const deviceId = await getDeviceId();
  const r = await fetch('https://darkflow-server.vercel.app/api/reset-device', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ key: key.trim().toUpperCase(), deviceId })
  });
  return await r.json();
}

// ════════════════════════════════════════════════════════════════════════════
// TABS
// ════════════════════════════════════════════════════════════════════════════
function switchTab(tab) {
  document.getElementById('tabMain').classList.toggle('active', tab === 'main');
  document.getElementById('tabGen').classList.toggle('active',  tab === 'gen');
  document.getElementById('panelMain').classList.toggle('active', tab === 'main');
  document.getElementById('panelGen').classList.toggle('active',  tab === 'gen');
}

// ════════════════════════════════════════════════════════════════════════════
// GERADOR DE META-PROMPT
// ════════════════════════════════════════════════════════════════════════════
const ESTILOS = {
  cinematic:  'cinematic visual language, photorealistic film still, realistic depth of field, professional cinematography, no illustration, no animation',
  anime:      'anime art style, japanese animation aesthetics, cel shading, expressive facial features, clean lineart, stylized proportions, no photorealism',
  realismo:   'photorealistic photography, real-world camera capture, natural perspective, authentic textures, sharp focus, no illustration',
  artistico:  'painterly visual style, visible brush strokes, artistic texture, expressive color palette, non-photorealistic rendering',
  fantasy:    'fantasy illustration style, imaginative environments, epic lighting, mythical atmosphere, high visual drama',
  educativo:  'simple illustrative drawing style, educational visuals, clear shapes, high readability, minimal detail',
  pop:        'bold pop visual style, high contrast colors, exaggerated shapes, graphic and vibrant composition',
  tech:       'clean tech aesthetic, structured layout, minimal design, modern digital surfaces, neutral palette',
  terror:     'dark horror atmosphere, unsettling low-key lighting, ominous composition, psychological tension, no gore',
  retro:      'analog retro aesthetic, film grain, VHS texture, nostalgic color grading, imperfect signal',
  cartoon3d:  '3D cartoon rendering, stylized characters, smooth rounded surfaces, soft global illumination, expressive proportions',
};
const IDIOMAS = {
  'pt-BR': { textoBase: 'Portuguese (pt-BR)', langRule: 'if any visible text must be in Portuguese (pt-BR)' },
  'es-ES': { textoBase: 'Spanish (es-ES)',    langRule: 'if any visible text must be in Spanish (es-ES)' },
  'en-US': { textoBase: 'English (en-US)',    langRule: 'if any visible text must be in English (en-US)' },
};

function gerarMetaPrompt(roteiro, estilo, idioma, numCenas) {
  const estiloCmd = ESTILOS[estilo] || ESTILOS.cinematic;
  const idiomaObj = IDIOMAS[idioma] || IDIOMAS['pt-BR'];
  return `You are a visual prompt engineer specialized in generating scene-by-scene CSV scripts for Google Veo3 video generation.

Based on the script below, generate a CSV file with exactly ${numCenas} scenes in CenaDrop format.

MANDATORY RULES:
- Divide the script into ${numCenas} proportional segments, one scene per segment
- Keep the original narrative order
- Each scene represents approximately 8 seconds of video
- ALL visual fields must be in English — optimized for Veo3
- The texto_base field must be written in ${idiomaObj.textoBase}
- No pronouns (he, she, it, his, her, its) — use nouns and gerund actions
- Return ONLY the raw CSV content — no explanations, no markdown, no code blocks

GLOBAL VISUAL STYLE (apply consistently to all scenes):
${estiloCmd}

CSV FORMAT (semicolon separator, every field in double quotes):
scene_number;texto_base;subject_and_scale;environment_and_atmosphere;movement_and_cinematography;native_audio;rules

FIELD INSTRUCTIONS:
- scene_number: sequential integer
- texto_base: brief narrative description in ${idiomaObj.textoBase}
- subject_and_scale: main subject + state + shot size. No pronouns
- environment_and_atmosphere: location, time, weather, lighting, mood. In English
- movement_and_cinematography: camera movement, lens, depth of field, 16:9. In English
- native_audio: specific ambient sounds. No human dialogue
- rules: always write exactly — "${estiloCmd}, photorealistic rendering, real-world textures, subtle film grain, 16:9 aspect ratio, ${idiomaObj.langRule}, no watermark, no text overlay, sharp focus, clean composition."

SCRIPT:
${roteiro.trim()}`;
}

function copiarPrompt() {
  const txt = document.getElementById('promptText').textContent;
  navigator.clipboard.writeText(txt).then(() => {
    const btn = document.getElementById('btnCopyPrompt');
    btn.textContent = '✅ Copiado!'; btn.classList.add('copied');
    setTimeout(() => { btn.textContent = '📋 Copiar'; btn.classList.remove('copied'); }, 2500);
  });
}

function baixarCSV() {
  const raw   = document.getElementById('csvPasteArea').value.trim();
  const msgEl = document.getElementById('csvMsg');
  msgEl.className = 'csv-msg'; msgEl.textContent = '';
  if (!raw) { msgEl.textContent = '⚠️ Cole o conteúdo CSV antes de baixar.'; msgEl.classList.add('err'); return; }
  const firstLine = raw.split('\n')[0];
  if (!firstLine.includes('scene_number') && !firstLine.includes('subject_and_scale')) {
    msgEl.textContent = '⚠️ Não parece um CSV CenaDrop.'; msgEl.classList.add('err'); return;
  }
  const lines    = raw.split('\n').filter(l => l.trim().length > 0);
  const numCenas = lines.length - 1;
  const blob     = new Blob([raw], { type: 'text/csv;charset=utf-8;' });
  const url      = URL.createObjectURL(blob);
  const a        = document.createElement('a');
  a.href = url; a.download = `cenadrop_cenas_${numCenas}.csv`;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a); URL.revokeObjectURL(url);
  msgEl.textContent = `✅ ${numCenas} cenas exportadas!`; msgEl.classList.add('ok');
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN APP — roda sempre que o popup abre
// ════════════════════════════════════════════════════════════════════════════
async function _init() {
  const jsonZone    = document.getElementById('jsonZone');
  const jsonInput   = document.getElementById('jsonInput');
  const jsonTitle   = document.getElementById('jsonTitle');
  const jsonClear   = document.getElementById('jsonClear');
  const scenesPanel = document.getElementById('scenesPanel');
  const scenesList  = document.getElementById('scenesList');
  const selInfo     = document.getElementById('selInfo');
  const btnAll      = document.getElementById('btnAll');
  const btnNone     = document.getElementById('btnNone');
  const btnInvert   = document.getElementById('btnInvert');
  const statsRow    = document.getElementById('statsRow');
  const statSent    = document.getElementById('statSent');
  const statDl      = document.getElementById('statDl');
  const statTotal   = document.getElementById('statTotal');
  const startBtn    = document.getElementById('start');
  const stopBtn     = document.getElementById('stop');
  const btnDownload = document.getElementById('btnDownload');
  const statusDot   = document.getElementById('statusDot');
  const logCurrent  = document.getElementById('logCurrent');
  const logMsgs     = document.getElementById('logMsgs');
  const progressWrap= document.getElementById('progressWrap');
  const progressBar = document.getElementById('progressBar');
  const timerRow    = document.getElementById('timerRow');
  const timerVal    = document.getElementById('timerVal');

  let allScenes = [], isProcessing = false, totalSel = 0;
  let sentCount = 0, dlCount = 0, timerInterval = null;
  const logHistory = [];

  // ── Restaura estado ao reabrir ───────────────────────────────────────────
  const saved = await chrome.storage.local.get([
    'flow_running','flow_awaiting_download','flow_sent_count',
    'flow_dl_count','flow_total_sel','flow_last_status','flow_stop'
  ]);
  if (saved.flow_total_sel) {
    sentCount = saved.flow_sent_count || 0;
    dlCount   = saved.flow_dl_count   || 0;
    totalSel  = saved.flow_total_sel  || 0;
    statsRow.classList.add('visible');
    statSent.textContent  = sentCount;
    statDl.textContent    = dlCount;
    statTotal.textContent = totalSel;
    if (saved.flow_last_status) logCurrent.textContent = saved.flow_last_status;
    if (totalSel > 0) {
      const done = dlCount > 0 ? dlCount : sentCount;
      setProgress(done, totalSel);
    }
    if (saved.flow_awaiting_download && !saved.flow_stop) {
      // Estava aguardando clique em Baixar — restaura o botão
      btnDownload.style.display = 'block';
      startBtn.disabled = false;
      stopBtn.disabled  = true;
      setDot('active');
      addLog(saved.flow_last_status || '✅ Clique em Baixar quando os vídeos estiverem prontos!');
    } else if (saved.flow_running && !saved.flow_stop) {
      stopBtn.disabled  = false;
      startBtn.disabled = true;
      setDot('active');
    }
  }

  function addLog(msg) {
    logCurrent.textContent = msg;
    const el = document.createElement('div'); el.className = 'log-msg new'; el.textContent = msg;
    logHistory.push(el);
    if (logHistory.length > 30) logMsgs.removeChild(logHistory.shift());
    logMsgs.appendChild(el); logMsgs.scrollTop = logMsgs.scrollHeight;
    setTimeout(() => el.classList.remove('new'), 1000);
  }

  function setDot(s) { statusDot.className = 'status-dot' + (s !== 'idle' ? ' ' + s : ''); }
  function setProgress(done, total) {
    if (total === 0) { progressWrap.classList.remove('visible'); progressBar.style.width = '0%'; return; }
    progressWrap.classList.add('visible');
    progressBar.style.width = Math.round((done/total)*100) + '%';
  }
  function startTimer() {
    const start = Date.now(); timerRow.classList.add('visible');
    timerInterval = setInterval(() => {
      const e = Date.now()-start;
      timerVal.textContent = Math.floor(e/60000).toString().padStart(2,'0')+':'+Math.floor((e%60000)/1000).toString().padStart(2,'0');
    }, 1000);
  }
  function stopTimer() { clearInterval(timerInterval); timerInterval=null; timerRow.classList.remove('visible'); timerVal.textContent='00:00'; }
  function setProcessing(on) {
    isProcessing = on; startBtn.disabled = on || totalSel === 0; stopBtn.disabled = !on;
    if (on) { startTimer(); statsRow.classList.add('visible'); } else stopTimer();
  }
  function updateSelInfo() {
    const checked = scenesList.querySelectorAll('input:checked').length;
    totalSel = checked;
    selInfo.textContent = checked + ' selecionada' + (checked !== 1 ? 's' : '');
    startBtn.disabled = isProcessing || checked === 0;
    btnAll.classList.toggle('active', checked === allScenes.length);
    btnNone.classList.toggle('active', checked === 0);
  }
  function renderScenes(scenes) {
    scenesList.innerHTML = '';
    scenes.forEach((s,i) => {
      const item = document.createElement('div'); item.className = 'scene-item checked';
      const cb   = document.createElement('input'); cb.type='checkbox'; cb.checked=true; cb.dataset.index=i;
      const num  = document.createElement('span');  num.className='scene-num'; num.textContent='#'+String(s.scene_number||i+1).padStart(2,'0');
      const txt  = document.createElement('span');  txt.className='scene-text'; txt.textContent=s.subject_and_scale?.substring(0,100)||s.texto_base||s.prompt?.substring(0,100)||'';
      item.append(cb,num,txt);
      item.addEventListener('click', e => { if(e.target===cb) return; cb.checked=!cb.checked; item.classList.toggle('checked',cb.checked); updateSelInfo(); });
      cb.addEventListener('change', () => { item.classList.toggle('checked',cb.checked); updateSelInfo(); });
      scenesList.appendChild(item);
    });
    updateSelInfo(); scenesPanel.classList.add('visible');
  }
  function getSelected() {
    const sel=[];
    scenesList.querySelectorAll('.scene-item').forEach((item,i) => { if(item.querySelector('input')?.checked&&allScenes[i]) sel.push(allScenes[i]); });
    return sel;
  }
  function parseCSV(text) {
    const lines=text.trim().split('\n'); if(lines.length<2) return [];
    const delim=lines[0].includes(';')?';':',';
    function splitLine(line){ const result=[]; let cur='',inQ=false; for(let i=0;i<line.length;i++){ const c=line[i]; if(c==='"'){inQ=!inQ;continue;} if(c===delim&&!inQ){result.push(cur.trim());cur='';continue;} cur+=c; } result.push(cur.trim()); return result; }
    const headers=splitLine(lines[0]); const scenes=[];
    for(let i=1;i<lines.length;i++){
      if(!lines[i].trim()) continue;
      const vals=splitLine(lines[i]); const obj={};
      headers.forEach((h,idx)=>{ obj[h.trim()]=vals[idx]??''; });
      const prompt=[obj.subject_and_scale,obj.environment_and_atmosphere,obj.movement_and_cinematography,obj.native_audio,obj.rules].filter(Boolean).join(' ');
      scenes.push({ scene_number:obj.scene_number||i, prompt, subject_and_scale:obj.subject_and_scale||'', ...obj });
    }
    return scenes.filter(s=>s.prompt.trim().length>0);
  }
  function parseJSON(text) {
    const data=JSON.parse(text); const scenes=data.scenes||(Array.isArray(data)?data:null);
    if(!scenes?.length) throw new Error('JSON sem cenas!');
    return scenes.filter(s=>(s.prompt||s.text||'').trim().length>0);
  }

  btnAll.addEventListener('click',()=>{ scenesList.querySelectorAll('.scene-item').forEach(item=>{ const cb=item.querySelector('input'); cb.checked=true; item.classList.add('checked'); }); updateSelInfo(); });
  btnNone.addEventListener('click',()=>{ scenesList.querySelectorAll('.scene-item').forEach(item=>{ const cb=item.querySelector('input'); cb.checked=false; item.classList.remove('checked'); }); updateSelInfo(); });
  btnInvert.addEventListener('click',()=>{ scenesList.querySelectorAll('.scene-item').forEach(item=>{ const cb=item.querySelector('input'); cb.checked=!cb.checked; item.classList.toggle('checked',cb.checked); }); updateSelInfo(); });

  jsonZone.addEventListener('click', e=>{ if(e.target===jsonClear) return; if(!isProcessing) jsonInput.click(); });
  jsonInput.addEventListener('change', async e=>{
    const file=e.target.files[0]; if(!file) return;
    try {
      const text=await file.text(); const isCSV=file.name.toLowerCase().endsWith('.csv');
      const valid=isCSV?parseCSV(text):parseJSON(text);
      if(!valid.length){ addLog('❌ Nenhuma cena encontrada!'); return; }
      allScenes=valid; jsonZone.classList.add('loaded');
      const name=file.name.length>42?file.name.substring(0,39)+'...':file.name;
      jsonTitle.textContent='✅ '+valid.length+' cenas ['+(isCSV?'CSV':'JSON')+'] — '+name;
      jsonClear.style.display='block'; statTotal.textContent=valid.length;
      statsRow.classList.add('visible'); renderScenes(valid);
      addLog((isCSV?'CSV':'JSON')+' carregado: '+valid.length+' cenas');
    } catch(err){ addLog('❌ Erro: '+err.message); }
  });
  jsonClear.addEventListener('click', e=>{
    e.stopPropagation(); allScenes=[]; totalSel=0;
    jsonZone.classList.remove('loaded'); jsonTitle.textContent='Clique para carregar JSON ou CSV';
    jsonClear.style.display='none'; jsonInput.value='';
    scenesPanel.classList.remove('visible'); scenesList.innerHTML='';
    statsRow.classList.remove('visible'); startBtn.disabled=true;
    setProgress(0,0); addLog('Arquivo removido');
  });

  // ── Iniciar ───────────────────────────────────────────────────────────────
  startBtn.addEventListener('click', async ()=>{
    const sel=getSelected(); if(!sel.length){ addLog('❌ Selecione pelo menos 1 cena!'); return; }
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); if(!tab){ addLog('❌ Nenhuma aba ativa!'); return; }
    if(!tab.url?.includes('labs.google')||!tab.url?.includes('/tools/flow/project/')){ addLog('⚠️ Abra um PROJETO no Google Flow!'); return; }
    sentCount=0; dlCount=0; totalSel=sel.length;
    setProcessing(true); setProgress(0,totalSel);
    statSent.textContent='0'; statDl.textContent='0'; statTotal.textContent=totalSel;
    setDot('active'); btnDownload.style.display='none';
    addLog('Iniciando '+totalSel+' cenas...');
    await chrome.storage.local.remove(['flow_stop','flow_download_ready']);
    await chrome.storage.local.set({ flow_awaiting_download:false, flow_sent_count:0, flow_dl_count:0, flow_total_sel:totalSel });
    chrome.tabs.sendMessage(tab.id,{action:'processJson',scenes:sel});
  });

  // ── Parar — reset total ───────────────────────────────────────────────────
  stopBtn.addEventListener('click', async ()=>{
    await chrome.storage.local.set({flow_stop:true, flow_running:false, flow_awaiting_download:false});
    await chrome.storage.local.remove(['flow_total_sel','flow_sent_count','flow_dl_count','flow_last_status','flow_download_ready']);
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(tab) chrome.tabs.sendMessage(tab.id,{action:'stop'}).catch(()=>{});
    setProcessing(false); setDot('idle'); btnDownload.style.display='none';
    statsRow.classList.remove('visible');
    setProgress(0,0); addLog('⏹ Parado e zerado.');
  });

  // ── Botão Baixar — exatamente como v2.1 ──────────────────────────────────
  btnDownload.addEventListener('click', async ()=>{
    btnDownload.style.display='none'; addLog('⬇️ Iniciando downloads...');
    await chrome.storage.local.set({flow_download_ready:true, flow_awaiting_download:false});
  });

  // ── Mensagens do content script ───────────────────────────────────────────
  chrome.runtime.onMessage.addListener(req=>{
    if(req.action!=='updateStatus') return;
    const {status,sent,downloaded,allSent,allDone}=req;
    if(sent)       { sentCount++; statSent.textContent=sentCount; setProgress(sentCount,totalSel); chrome.storage.local.set({flow_sent_count:sentCount}); }
    if(downloaded) { dlCount++;   statDl.textContent=dlCount;     setProgress(dlCount,totalSel);   chrome.storage.local.set({flow_dl_count:dlCount}); }
    if(allDone) {
      setProcessing(false); setDot(req.failedScenes?'error':'done'); setProgress(totalSel,totalSel);
      chrome.storage.local.set({flow_running:false, flow_awaiting_download:false});
      startBtn.disabled=totalSel===0; stopBtn.disabled=true; btnDownload.style.display='none';
      if(req.failedScenes) addLog('⚠️ Não baixados: '+req.failedScenes);
      addLog(status||'🎉 Concluído!'); return;
    }
    if(allSent) {
      // Só mostra botão Baixar se não foi um stop/reset
      chrome.storage.local.get(['flow_stop']).then(s => {
        if (s.flow_stop) return; // foi parado — não mostra Baixar
        setProcessing(false); startBtn.disabled=false; setDot('active');
        btnDownload.style.display='block';
        chrome.storage.local.set({flow_awaiting_download:true, flow_last_status: status||'✅ Envio concluído! Clique em Baixar quando pronto.'});
        addLog(status||'✅ Envio concluído! Clique em Baixar quando pronto.');
      });
      return;
    }
    if(status) {
      chrome.storage.local.set({flow_last_status: status});
      addLog(status);
    }
  });

  // ── Gerar CSV ─────────────────────────────────────────────────────────────
  document.getElementById('btnGerarPrompt').addEventListener('click', ()=>{
    const roteiro  = document.getElementById('genRoteiro').value.trim();
    const estilo   = document.getElementById('genEstilo').value;
    const idioma   = document.getElementById('genIdioma').value;
    const numCenas = parseInt(document.getElementById('genCenas').value)||30;
    if(!roteiro){ alert('Cole seu roteiro antes de gerar o prompt!'); return; }
    const prompt = gerarMetaPrompt(roteiro,estilo,idioma,numCenas);
    document.getElementById('promptText').textContent = prompt;
    document.getElementById('promptResult').classList.add('visible');
    document.getElementById('funilBox').style.display = 'block';
  });
  document.getElementById('btnCopyPrompt').addEventListener('click', copiarPrompt);
  document.getElementById('btnCenasUp').addEventListener('click',   ()=>document.getElementById('genCenas').stepUp());
  document.getElementById('btnCenasDown').addEventListener('click', ()=>document.getElementById('genCenas').stepDown());
  document.getElementById('btnDlCsv').addEventListener('click', baixarCSV);
}

// ════════════════════════════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('licBtn').addEventListener('click', activateLicense);
  document.getElementById('licKey').addEventListener('keydown', e=>{ if(e.key==='Enter') activateLicense(); });
  document.getElementById('licKey').addEventListener('input',  e=>{ formatKey(e.target); });
  document.getElementById('logoutBtn').addEventListener('click', logout);
  document.getElementById('tabMain').addEventListener('click', ()=>switchTab('main'));
  document.getElementById('tabGen').addEventListener('click',  ()=>switchTab('gen'));

  // Reset device modal
  const modalReset    = document.getElementById('modalReset');
  const modalStatus   = document.getElementById('modalStatus');
  const resetKeyInput = document.getElementById('resetKey');

  document.getElementById('btnResetDevice').addEventListener('click', ()=>{
    resetKeyInput.value=''; modalStatus.textContent=''; modalStatus.className='modal-status';
    document.getElementById('modalConfirm').disabled=false;
    document.getElementById('modalConfirm').textContent='Desvincular';
    modalReset.classList.add('visible'); setTimeout(()=>resetKeyInput.focus(),100);
  });
  document.getElementById('modalCancel').addEventListener('click', ()=>modalReset.classList.remove('visible'));
  modalReset.addEventListener('click', e=>{ if(e.target===modalReset) modalReset.classList.remove('visible'); });
  resetKeyInput.addEventListener('input', e=>formatKey(e.target));
  resetKeyInput.addEventListener('keydown', e=>{ if(e.key==='Enter') document.getElementById('modalConfirm').click(); });
  document.getElementById('modalConfirm').addEventListener('click', async ()=>{
    const key = resetKeyInput.value.trim();
    if(key.length<8){ modalStatus.textContent='Digite sua chave completa.'; modalStatus.className='modal-status err'; return; }
    const btn = document.getElementById('modalConfirm');
    btn.disabled=true; btn.textContent='Aguarde...'; modalStatus.textContent='';
    try {
      const data = await resetDevice(key);
      if(data.ok) {
        await chrome.storage.local.remove(['cd_license_key','cd_license_valid','cd_last_check','cd_device_id']);
        modalStatus.textContent='✅ Dispositivo desvinculado!'; modalStatus.className='modal-status ok';
        setTimeout(()=>{ modalReset.classList.remove('visible'); showLicenseScreen(); }, 2000);
      } else {
        modalStatus.textContent='❌ '+(data.error||'Erro ao desvincular.'); modalStatus.className='modal-status err';
        btn.disabled=false; btn.textContent='Desvincular';
      }
    } catch(e) {
      modalStatus.textContent='❌ Erro de conexão.'; modalStatus.className='modal-status err';
      btn.disabled=false; btn.textContent='Desvincular';
    }
  });

  checkLicense();
});
