// background.js — Darkscript Flow ULTRA v3.0

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Darkscript Flow ULTRA v3.0] Instalado');
});

let _renameQueue = [];

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'updateStatus') {
    // Só repassa ao popup se a mensagem vem do content script (tem sender.tab)
    // Isso evita loop e contagem dupla
    if (sender.tab) {
      chrome.runtime.sendMessage(msg).catch(() => {});
    }
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'setNextDownloadName') {
    _renameQueue.push(msg.filename);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'getTabId') {
    sendResponse({ tabId: sender.tab?.id });
    return true;
  }

  sendResponse({ ok: true });
  return true;
});

// ── Renomeia downloads ────────────────────────────────────────────────────────
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (_renameQueue.length === 0) { suggest(); return; }

  const isFlow = item.url.includes('labs.google') ||
                 item.url.includes('googleapis') ||
                 item.url.includes('getMediaUrl') ||
                 item.filename.includes('mp4');

  if (!isFlow) { suggest(); return; }

  const prefix = _renameQueue.shift();
  const ext = item.filename.split('.').pop() || 'mp4';
  const newName = `${prefix}.${ext}`;
  console.log(`[Darkscript Flow ULTRA] Download: ${item.filename} → ${newName}`);
  suggest({ filename: newName, conflictAction: 'uniquify' });
  return true;
});
